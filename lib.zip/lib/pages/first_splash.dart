import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';


class FirstSplash extends StatelessWidget {
  const FirstSplash({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color.fromARGB(255, 125, 151, 40),
      body: Padding(
        padding: const EdgeInsets.only(
          top: 220,
          left: 117,
          right: 117,
        ),
        child: Column(
          children: [
            Center(
              child: Image.asset(
                'assets/Logo Uis.png',
                width: 140,
              ),
            ),
            SizedBox(
              height: 169,
            ),
            Text(
              'UNIVERSITAS IBNU SINA',
              style: GoogleFonts.dmSerifDisplay(
                backgroundColor: Color.fromARGB(255, 240, 240, 235),
              )
            ),
          ],
        ),
      ),
    );
  }
}
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';


class SecoundSplash extends StatelessWidget {
  const SecoundSplash({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
    children: [
      Container(
        decoration: BoxDecoration(
          image: DecorationImage(image: AssetImage('assets/bag.png',),
          ),
        ),
      ),
      Padding(
        padding: const EdgeInsets.only(
          top: 75,
          left: 60,
        ),
        child: Row(
          children: [
            Image.asset(
              'assets/Logo Uis.png',
              width: 51,
            ),
            SizedBox(
              width: 18,
            ),
            Text(
              'UIS UNGGUL',
              style: GoogleFonts.montserrat(
                color: Color(0xffFFFFFF),
                fontWeight: FontWeight.bold,
                fontSize: 32,
              ),
            ),
          ],
        ),
      ),
    ],
      )
    );
  }
}
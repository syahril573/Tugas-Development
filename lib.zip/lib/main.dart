import 'package:flutter/material.dart';
import 'package:syahril/pages/second_splash.dart';
// import 'package:syahril/pages/first_splash.dart';


void main() =>runApp(MyApp());

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home : SecoundSplash (),
    );
  }
}